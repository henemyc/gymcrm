<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Dashboard') — {{ \App\Models\Setting::get('company_name', 'GymLead CRM') }}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('assets/css/app.css') }}?v=5">
</head>
<body>
@php
    $user = auth()->user();
    $company = \App\Models\Setting::get('company_name', 'GymLead CRM');
    $svg = fn (string $path) => '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'.$path.'</svg>';
@endphp
<div class="app" id="app-shell">
    <aside class="sidebar" id="sidebar">
        <a class="brand" href="{{ route('dashboard') }}">
            <span class="brand-mark">
                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19V8l8-5 8 5v11"/><path d="M9 19v-6h6v6"/></svg>
            </span>
            <span class="brand-copy">
                <strong>{{ $company }}</strong>
                <small>Sales CRM</small>
            </span>
        </a>

        <nav class="nav">
            <p class="nav-label">Overview</p>
            <a class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}" href="{{ route('dashboard') }}">
                {!! $svg('<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>') !!}
                Dashboard
            </a>
            <a class="nav-link {{ request()->routeIs('leads.index') || request()->routeIs('leads.show') || request()->routeIs('leads.edit') ? 'active' : '' }}" href="{{ route('leads.index') }}">
                {!! $svg('<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="4" cy="6" r="1.2"/><circle cx="4" cy="12" r="1.2"/><circle cx="4" cy="18" r="1.2"/>') !!}
                {{ $user->isAdmin() ? 'Leads' : 'My leads' }}
            </a>
            <a class="nav-link {{ request()->routeIs('leads.create') ? 'active' : '' }}" href="{{ route('leads.create') }}">
                {!! $svg('<circle cx="12" cy="8" r="3.2"/><path d="M5.5 19a6.5 6.5 0 0 1 13 0"/><path d="M19 8v4M21 10h-4"/>') !!}
                Add lead
            </a>

            @if($user->isAdmin())
                <p class="nav-label">Acquisition</p>
                <a class="nav-link {{ request()->routeIs('scraper.*') ? 'active' : '' }}" href="{{ route('scraper.index') }}">
                    {!! $svg('<circle cx="12" cy="12" r="9"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/><circle cx="12" cy="12" r="3"/>') !!}
                    Maps scraper
                </a>
                <a class="nav-link {{ request()->routeIs('leads.import*') ? 'active' : '' }}" href="{{ route('leads.import.form') }}">
                    {!! $svg('<path d="M12 3v12"/><path d="m8 11 4 4 4-4"/><path d="M5 21h14"/>') !!}
                    Import
                </a>

                <p class="nav-label">Admin</p>
                <a class="nav-link {{ request()->routeIs('users.*') ? 'active' : '' }}" href="{{ route('users.index') }}">
                    {!! $svg('<circle cx="9" cy="8" r="3"/><path d="M3.5 19a5.5 5.5 0 0 1 11 0"/><circle cx="17" cy="9" r="2.2"/><path d="M16 19a4.2 4.2 0 0 1 5-4"/>') !!}
                    Team
                </a>
                <a class="nav-link {{ request()->routeIs('activity.*') ? 'active' : '' }}" href="{{ route('activity.index') }}">
                    {!! $svg('<path d="M4 5h16M4 12h10M4 19h16"/><circle cx="18" cy="12" r="2"/>') !!}
                    Activity
                </a>
                <a class="nav-link {{ request()->routeIs('settings.*') ? 'active' : '' }}" href="{{ route('settings.index') }}">
                    {!! $svg('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9c.3.7 1 1.1 1.5 1.1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>') !!}
                    Settings
                </a>
            @endif
        </nav>

        <div class="sidebar-foot">
            <a href="{{ route('profile.edit') }}" class="who">
                <span class="avatar">{{ strtoupper(substr($user->name, 0, 1)) }}</span>
                <span class="who-copy">
                    <strong>{{ $user->name }}</strong>
                    <small>{{ ucfirst($user->role) }}</small>
                </span>
            </a>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button class="logout" type="submit" title="Sign out">
                    {!! $svg('<path d="M9 21H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>') !!}
                    Sign out
                </button>
            </form>
        </div>
    </aside>

    <div class="workspace">
        <header class="chrome">
            <button class="icon-btn menu-btn" type="button" id="menu-btn" aria-label="Open menu">
                <svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
            </button>
            <div class="chrome-title">
                <h1>@yield('heading', 'Dashboard')</h1>
                <p>@yield('subhead', 'Pipeline, ownership, and follow-through.')</p>
            </div>
            <div class="chrome-actions">
                @yield('actions')
            </div>
        </header>
        <div class="flash-stack" id="flash-stack">
            @if(session('success'))
                <div class="toast toast-ok">{{ session('success') }}</div>
            @endif
            @if($errors->any())
                <div class="toast toast-err">{{ $errors->first() }}</div>
            @endif
        </div>
        <div class="canvas">
            @yield('content')
        </div>
    </div>
    <div class="backdrop" id="backdrop"></div>
</div>
<div id="app-loader" class="app-loader" hidden>
    <div class="loader-card">
        <div class="spinner"></div>
        <p id="app-loader-text">Working…</p>
    </div>
</div>
<script>
    window.GymLead = {
        csrf: document.querySelector('meta[name="csrf-token"]').content,
        isAdmin: @json($user->isAdmin()),
    };
</script>
<script src="{{ asset('assets/js/app.js') }}?v=5"></script>
<script>
function closeUserModal() {
    var m = document.getElementById('user-modal');
    if (!m) return;
    m.style.display = 'none';
    m.classList.remove('is-open');
    m.setAttribute('hidden', 'hidden');
}
function openUserModal() {
    var m = document.getElementById('user-modal');
    if (!m) return;
    m.removeAttribute('hidden');
    m.classList.add('is-open');
    m.style.display = 'grid';
}
</script>
@stack('scripts')
</body>
</html>
