@extends('layouts.app')
@section('title', 'Maps scraper')
@section('heading', 'Maps scraper')
@section('subhead', 'Search → review → assign. First page loads instantly; load more when you need it.')
@section('actions')
    <a class="btn btn-ghost" href="{{ route('settings.index') }}">API settings</a>
@endsection
@section('content')
@if(!$hasKey)
    <div class="alert err">Add a Google Maps API key in <a href="{{ route('settings.index') }}">Settings</a> before searching.</div>
@endif

<nav class="steps" id="scrape-steps">
    <div class="step on" data-step="1"><b>1</b> Search location</div>
    <div class="step" data-step="2"><b>2</b> Review & select</div>
    <div class="step" data-step="3"><b>3</b> Assign to staff</div>
</nav>

<div id="success-banner" class="success-banner" hidden></div>

<section class="panel" id="search-panel">
    <header class="panel-h"><h2>1. Find businesses</h2></header>
    <form id="scrape-form" class="form-grid">
        <label class="span-2">Location
            <input type="text" name="location" id="location" placeholder="City, area, or landmark — then pick a suggestion" autocomplete="off" required>
            <input type="hidden" name="place_id" id="place_id">
            <div id="suggest" class="suggest" hidden></div>
        </label>
        <label>Keyword
            <input name="keyword" value="{{ $defaults['keyword'] }}" required>
        </label>
        <label>Place type
            <select name="type">
                @foreach($types as $k => $label)
                    <option value="{{ $k }}" @selected($k === 'gym')>{{ $label }}</option>
                @endforeach
            </select>
        </label>
        <label class="span-2">Radius
            <input type="hidden" name="radius" id="radius" value="{{ $defaults['radius'] }}">
            <div class="chips" id="radius-chips">
                <button type="button" class="chip" data-m="1000">1 km</button>
                <button type="button" class="chip" data-m="3000">3 km</button>
                <button type="button" class="chip" data-m="5000">5 km</button>
                <button type="button" class="chip" data-m="10000">10 km</button>
            </div>
        </label>
        <label>Mode
            <select name="mode">
                <option value="nearby">Nearby search</option>
                <option value="text">Text search</option>
            </select>
        </label>
        <div class="span-2">
            <button class="btn btn-primary" type="submit" id="search-btn" {{ $hasKey ? '' : 'disabled' }}>Search Maps</button>
            <span class="hint">Results appear after the first page (~20 places). Use Load more for the next Google page.</span>
        </div>
    </form>
</section>

<section class="panel" id="results-panel" hidden>
    <header class="panel-h">
        <h2>2. Review results <small id="result-meta"></small></h2>
        <div class="seg" id="result-filter">
            <button type="button" class="on" data-f="all">All</button>
            <button type="button" data-f="new">New only</button>
            <button type="button" data-f="dup">Duplicates</button>
        </div>
    </header>
    <div class="kpi-row">
        <div><span>Found</span><strong id="kpi-found">0</strong></div>
        <div><span>New</span><strong id="kpi-new">0</strong></div>
        <div><span>Already in CRM</span><strong id="kpi-dup">0</strong></div>
        <div><span>Selected</span><strong id="kpi-sel">0</strong></div>
    </div>
    <div class="filters">
        <input type="search" id="result-q" placeholder="Filter this list…">
        <label class="check"><input type="checkbox" id="pick-all"> Select all new</label>
        <button class="btn btn-ghost" type="button" id="more-btn" hidden>Load more from Maps</button>
    </div>
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th class="col-check"></th>
                    <th>Business</th>
                    <th>Address</th>
                    <th>Rating</th>
                    <th>Phone</th>
                    <th>Flag</th>
                </tr>
            </thead>
            <tbody id="scrape-rows"></tbody>
        </table>
    </div>
    <div class="pager" id="scrape-pager"></div>
</section>

<div class="scrape-dock" id="scrape-dock" hidden>
    <div>
        <strong id="dock-count">0 selected</strong>
        <div class="muted">Duplicates stay out of the assign batch.</div>
    </div>
    <button class="btn btn-ghost" type="button" id="enrich-btn" style="background:#1e293b;color:#fff;border-color:#334155">Load phones</button>
    <button class="btn btn-primary" type="button" id="assign-open">Assign to staff</button>
</div>

<section class="panel">
    <header class="panel-h"><h2>Recent scrape jobs</h2></header>
    <div id="jobs" class="list"></div>
    <div class="pager" id="jobs-pager"></div>
</section>

<div class="modal" id="assign-modal" style="display:none" onclick="if (event.target === this) closeAssignModal();">
    <div class="modal-card" onclick="event.stopPropagation();">
        <header class="panel-h">
            <h2>3. Assign selected leads</h2>
            <button type="button" class="btn btn-ghost" onclick="closeAssignModal(); return false;">Close</button>
        </header>
        <p class="muted" id="assign-summary">0 new places will be saved and assigned.</p>
        <form id="assign-form" class="stack" style="margin-top:12px">
            <label>Staff owner
                <select id="assign-staff" required>
                    <option value="">Select staff</option>
                    @foreach($staff as $s)
                        <option value="{{ $s->id }}">{{ $s->name }}</option>
                    @endforeach
                </select>
            </label>
            <p class="hint">Phones and websites are fetched from Place Details during save (if enabled in Settings).</p>
            <div style="display:flex;gap:8px">
                <button class="btn btn-primary" type="submit" id="assign-btn">Save & assign</button>
                <button class="btn btn-ghost" type="button" onclick="closeAssignModal(); return false;">Cancel</button>
            </div>
        </form>
    </div>
</div>
@endsection
@push('scripts')
<script>
function closeAssignModal() {
    var m = document.getElementById('assign-modal');
    m.style.display = 'none';
    m.classList.remove('is-open');
}
function openAssignModal() {
    var m = document.getElementById('assign-modal');
    m.style.display = 'grid';
    m.classList.add('is-open');
}
GymLead.ready(function () {
    var jobId = null;
    var items = [];
    var timer = null;
    var previewPage = 1;
    var previewPer = 15;
    var jobsPage = 1;
    var picked = {};
    var hasMore = false;
    var filter = 'all';
    var loc = document.getElementById('location');
    var box = document.getElementById('suggest');
    var searchBtn = document.getElementById('search-btn');
    var moreBtn = document.getElementById('more-btn');
    var enrichBtn = document.getElementById('enrich-btn');
    var assignBtn = document.getElementById('assign-btn');

    function setStep(n) {
        document.querySelectorAll('#scrape-steps .step').forEach(function (el) {
            var s = parseInt(el.getAttribute('data-step'), 10);
            el.classList.toggle('on', s === n);
            el.classList.toggle('done', s < n);
        });
    }

    var currentRadius = String({{ (int) $defaults['radius'] }});
    document.querySelectorAll('#radius-chips .chip').forEach(function (chip) {
        if (chip.getAttribute('data-m') === currentRadius) chip.classList.add('on');
        chip.addEventListener('click', function () {
            document.querySelectorAll('#radius-chips .chip').forEach(function (c) { c.classList.remove('on'); });
            chip.classList.add('on');
            document.getElementById('radius').value = chip.getAttribute('data-m');
        });
    });

    loc.addEventListener('input', function () {
        document.getElementById('place_id').value = '';
        clearTimeout(timer);
        var q = loc.value.trim();
        if (q.length < 2) { box.hidden = true; return; }
        timer = setTimeout(function () {
            GymLead.get('{{ route('scraper.autocomplete') }}?q=' + encodeURIComponent(q)).then(function (res) {
                if (!res.ok) return;
                box.hidden = false;
                box.innerHTML = (res.predictions || []).map(function (p) {
                    return '<button type="button" data-id="' + GymLead.esc(p.place_id) + '">' + GymLead.esc(p.description) + '</button>';
                }).join('') || '<p class="muted">No matches</p>';
            });
        }, 220);
    });
    box.addEventListener('click', function (e) {
        var b = e.target.closest('button');
        if (!b) return;
        loc.value = b.textContent;
        document.getElementById('place_id').value = b.getAttribute('data-id');
        box.hidden = true;
    });
    document.addEventListener('click', function (e) {
        if (!box.contains(e.target) && e.target !== loc) box.hidden = true;
    });

    document.getElementById('scrape-form').addEventListener('submit', function (e) {
        e.preventDefault();
        if (!document.getElementById('place_id').value && !loc.value.trim()) {
            return GymLead.toast('Type a location and pick a suggestion.', 'err');
        }
        GymLead.busy(searchBtn, true, 'Searching…');
        GymLead.loading(true, 'Querying Google Places…');
        GymLead.post('{{ route('scraper.search') }}', GymLead.formData(this)).then(function (res) {
            GymLead.busy(searchBtn, false);
            GymLead.loading(false);
            if (!res.ok) return;
            jobId = res.job_id;
            items = res.items || [];
            picked = {};
            previewPage = 1;
            hasMore = !!res.has_more;
            document.getElementById('results-panel').hidden = false;
            document.getElementById('success-banner').hidden = true;
            moreBtn.hidden = !hasMore;
            setStep(2);
            render();
            document.getElementById('results-panel').scrollIntoView({ behavior: 'smooth', block: 'start' });
            GymLead.toast((res.found || 0) + ' places loaded.');
            loadJobs();
        }).catch(function () {
            GymLead.busy(searchBtn, false);
            GymLead.loading(false);
        });
    });

    moreBtn.addEventListener('click', function () {
        if (!jobId) return;
        GymLead.busy(moreBtn, true, 'Loading page…');
        GymLead.loading(true, 'Fetching next Google page…');
        GymLead.post('{{ route('scraper.more') }}', { job_id: jobId }).then(function (res) {
            GymLead.busy(moreBtn, false);
            GymLead.loading(false);
            if (!res.ok) return;
            items = items.concat(res.items || []);
            hasMore = !!res.has_more;
            moreBtn.hidden = !hasMore;
            render();
            GymLead.toast('Added ' + (res.items || []).length + ' more places.');
        }).catch(function () {
            GymLead.busy(moreBtn, false);
            GymLead.loading(false);
        });
    });

    function visibleItems() {
        var q = (document.getElementById('result-q').value || '').toLowerCase();
        return items.map(function (it, i) { it._i = i; return it; }).filter(function (it) {
            if (filter === 'new' && it.is_duplicate) return false;
            if (filter === 'dup' && !it.is_duplicate) return false;
            if (!q) return true;
            return (it.name || '').toLowerCase().indexOf(q) !== -1 || (it.address || '').toLowerCase().indexOf(q) !== -1;
        });
    }

    function selectedPlaces() {
        return items.filter(function (it, i) { return picked[i] && !it.is_duplicate; });
    }

    function kpis() {
        var dups = items.filter(function (it) { return it.is_duplicate; }).length;
        document.getElementById('kpi-found').textContent = items.length;
        document.getElementById('kpi-new').textContent = items.length - dups;
        document.getElementById('kpi-dup').textContent = dups;
        document.getElementById('kpi-sel').textContent = selectedPlaces().length;
        document.getElementById('result-meta').textContent = items.length + ' loaded' + (hasMore ? ' · more available' : '');
    }

    function updateCount() {
        var n = selectedPlaces().length;
        document.getElementById('dock-count').textContent = n + ' selected';
        document.getElementById('kpi-sel').textContent = n;
        document.getElementById('scrape-dock').hidden = n === 0;
        document.getElementById('assign-summary').textContent = n + ' new place' + (n === 1 ? '' : 's') + ' will be saved and assigned.';
    }

    function render() {
        var vis = visibleItems();
        var last = Math.max(1, Math.ceil(vis.length / previewPer) || 1);
        if (previewPage > last) previewPage = last;
        var start = (previewPage - 1) * previewPer;
        var slice = vis.slice(start, start + previewPer);
        var tb = document.getElementById('scrape-rows');
        if (!slice.length) {
            tb.innerHTML = '<tr><td colspan="6"><div class="empty">No places in this view.</div></td></tr>';
        } else {
            tb.innerHTML = slice.map(function (it) {
                var i = it._i;
                var disabled = it.is_duplicate ? 'disabled' : '';
                var checked = picked[i] ? 'checked' : '';
                var flag = it.is_duplicate
                    ? '<span class="badge badge-duplicate">In CRM' + (it.existing_lead_id ? ' #' + it.existing_lead_id : '') + '</span>'
                    : '<span class="badge badge-new">New</span>';
                var initial = GymLead.esc((it.name || '?').charAt(0).toUpperCase());
                return '<tr class="' + (it.is_duplicate ? 'dim' : '') + '">' +
                    '<td class="col-check"><input type="checkbox" class="pick" data-i="' + i + '" ' + disabled + ' ' + checked + '></td>' +
                    '<td><div class="entity"><span class="avatar sm">' + initial + '</span><span><strong>' + GymLead.esc(it.name) + '</strong><div class="sub">' + GymLead.esc(it.category || '') + '</div></span></div></td>' +
                    '<td>' + GymLead.esc(it.address || '') + '</td>' +
                    '<td>' + GymLead.esc(String(it.rating || '—')) + '</td>' +
                    '<td>' + GymLead.esc(it.phone || '—') + '</td>' +
                    '<td>' + flag + '</td></tr>';
            }).join('');
        }
        document.querySelectorAll('.pick').forEach(function (c) {
            c.addEventListener('change', function () {
                if (c.checked) picked[c.getAttribute('data-i')] = true;
                else delete picked[c.getAttribute('data-i')];
                updateCount();
            });
        });
        GymLead.pager('scrape-pager', {
            current_page: previewPage,
            last_page: last,
            total: vis.length,
            per_page: previewPer
        }, function (p) { previewPage = p; render(); });
        kpis();
        updateCount();
    }

    document.getElementById('result-q').addEventListener('input', function () { previewPage = 1; render(); });
    document.getElementById('result-filter').addEventListener('click', function (e) {
        var b = e.target.closest('button');
        if (!b) return;
        filter = b.getAttribute('data-f');
        document.querySelectorAll('#result-filter button').forEach(function (x) { x.classList.toggle('on', x === b); });
        previewPage = 1;
        render();
    });
    document.getElementById('pick-all').addEventListener('change', function () {
        var on = this.checked;
        items.forEach(function (it, i) {
            if (it.is_duplicate) return;
            if (on) picked[i] = true; else delete picked[i];
        });
        render();
    });

    enrichBtn.addEventListener('click', function () {
        var sel = selectedPlaces();
        if (!sel.length) return GymLead.toast('Select places first.', 'err');
        GymLead.busy(enrichBtn, true, 'Loading…');
        GymLead.loading(true, 'Fetching phones and websites…');
        GymLead.post('{{ route('scraper.enrich') }}', {
            place_ids: sel.map(function (p) { return p.google_place_id; })
        }).then(function (res) {
            GymLead.busy(enrichBtn, false);
            GymLead.loading(false);
            if (!res.ok) return;
            (res.items || []).forEach(function (d) {
                items = items.map(function (it) {
                    if (it.google_place_id === d.google_place_id) return Object.assign({}, it, d);
                    return it;
                });
            });
            render();
            GymLead.toast('Contact details loaded.');
        }).catch(function () {
            GymLead.busy(enrichBtn, false);
            GymLead.loading(false);
        });
    });

    document.getElementById('assign-open').addEventListener('click', function () {
        if (!selectedPlaces().length) return GymLead.toast('Select at least one new place.', 'err');
        setStep(3);
        openAssignModal();
    });

    document.getElementById('assign-form').addEventListener('submit', function (e) {
        e.preventDefault();
        var sel = selectedPlaces();
        var staff = document.getElementById('assign-staff').value;
        if (!sel.length) return GymLead.toast('Select at least one new place.', 'err');
        if (!staff) return GymLead.toast('Pick a staff member.', 'err');
        if (!jobId) return GymLead.toast('Run a search first.', 'err');
        GymLead.busy(assignBtn, true, 'Saving…');
        GymLead.loading(true, 'Saving leads and assigning…');
        GymLead.post('{{ route('scraper.assign') }}', {
            job_id: jobId,
            assigned_to: staff,
            places: sel
        }).then(function (res) {
            GymLead.busy(assignBtn, false);
            GymLead.loading(false);
            if (!res.ok) return;
            closeAssignModal();
            var r = res.result || {};
            var banner = document.getElementById('success-banner');
            banner.hidden = false;
            banner.innerHTML = '<div><strong>' + GymLead.esc(res.message) + '</strong><div class="muted">' +
                (r.duplicates ? r.duplicates.length + ' duplicates skipped. ' : '') +
                (r.errors && r.errors.length ? r.errors.length + ' enrich errors. ' : '') +
                '</div></div><a class="btn btn-primary" href="{{ route('leads.index') }}">Open leads</a>';
            sel.forEach(function (p) {
                items = items.map(function (it) {
                    if (it.google_place_id === p.google_place_id) {
                        it.is_duplicate = true;
                    }
                    return it;
                });
            });
            picked = {};
            setStep(2);
            render();
            loadJobs();
            GymLead.toast(res.message);
        }).catch(function () {
            GymLead.busy(assignBtn, false);
            GymLead.loading(false);
        });
    });

    function loadJobs() {
        GymLead.get('{{ route('scraper.jobs') }}?page=' + jobsPage + '&per_page=10').then(function (res) {
            document.getElementById('jobs').innerHTML = (res.jobs || []).map(function (j) {
                return '<div class="rowlink"><strong>' + GymLead.esc(j.location_label || j.keyword || 'Job') + '</strong><small>' +
                    GymLead.esc(j.status) + ' · found ' + j.results_found + ' · saved ' + j.saved_count + '</small></div>';
            }).join('') || '<p class="muted">No jobs yet.</p>';
            if (res.meta) GymLead.pager('jobs-pager', res.meta, function (p) { jobsPage = p; loadJobs(); });
        });
    }
    loadJobs();
});
</script>
@endpush
