(function (w) {
    var G = w.GymLead || {};

    G.ready = function (fn) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', fn);
        } else {
            fn();
        }
    };

    G.esc = function (s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    };

    G.toast = function (msg, type) {
        var stack = document.getElementById('flash-stack');
        if (!stack) {
            alert(msg);
            return;
        }
        var el = document.createElement('div');
        el.className = 'toast ' + (type === 'err' ? 'toast-err' : 'toast-ok');
        el.textContent = msg;
        stack.appendChild(el);
        setTimeout(function () { el.remove(); }, 4500);
    };

    G.formData = function (form) {
        var o = {};
        new FormData(form).forEach(function (v, k) { o[k] = v; });
        return o;
    };

    function headers() {
        return {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'X-CSRF-TOKEN': G.csrf,
            'X-Requested-With': 'XMLHttpRequest'
        };
    }

    function parse(res) {
        return res.text().then(function (text) {
            var json = {};
            try { json = text ? JSON.parse(text) : {}; } catch (e) { json = { message: text }; }
            json._status = res.status;
            if (!res.ok) {
                var msg = json.message;
                if (json.errors) {
                    var first = Object.keys(json.errors)[0];
                    msg = json.errors[first][0];
                }
                G.toast(msg || 'Request failed', 'err');
                json.ok = false;
            }
            return json;
        });
    }

    G.get = function (url) {
        return fetch(url, { headers: headers(), credentials: 'same-origin' }).then(parse);
    };

    G.send = function (method, url, body) {
        return fetch(url, {
            method: method,
            headers: headers(),
            credentials: 'same-origin',
            body: JSON.stringify(body || {})
        }).then(parse);
    };

    G.post = function (url, body) { return G.send('POST', url, body); };

    G.postForm = function (url, formData) {
        return fetch(url, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'X-CSRF-TOKEN': G.csrf,
                'X-Requested-With': 'XMLHttpRequest'
            },
            credentials: 'same-origin',
            body: formData
        }).then(parse);
    };

    G.downloadPost = function (url, body, filename) {
        return fetch(url, {
            method: 'POST',
            headers: headers(),
            credentials: 'same-origin',
            body: JSON.stringify(body || {})
        }).then(function (res) {
            if (!res.ok) return parse(res);
            return res.blob().then(function (blob) {
                var a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = filename || 'export.csv';
                a.click();
            });
        });
    };

    G.pager = function (id, meta, onPage) {
        var el = document.getElementById(id);
        if (!el || !meta) return;
        var page = parseInt(meta.current_page, 10) || 1;
        var last = parseInt(meta.last_page, 10) || 1;
        var total = parseInt(meta.total, 10) || 0;
        var per = parseInt(meta.per_page, 10) || 15;
        var from = total === 0 ? 0 : ((page - 1) * per) + 1;
        var to = Math.min(page * per, total);
        var pages = [];
        for (var i = 1; i <= last; i++) {
            if (i === 1 || i === last || (i >= page - 2 && i <= page + 2)) {
                pages.push(i);
            } else if (pages[pages.length - 1] !== '…') {
                pages.push('…');
            }
        }
        var html = '<div class="pager-info">Showing ' + from + '–' + to + ' of ' + total + '</div><div class="pager-btns">';
        html += '<button type="button" data-p="' + Math.max(1, page - 1) + '"' + (page <= 1 ? ' disabled' : '') + '>Prev</button>';
        pages.forEach(function (p) {
            if (p === '…') {
                html += '<span class="pager-ellipsis">…</span>';
            } else {
                html += '<button type="button" class="' + (p === page ? 'active' : '') + '" data-p="' + p + '">' + p + '</button>';
            }
        });
        html += '<button type="button" data-p="' + Math.min(last, page + 1) + '"' + (page >= last ? ' disabled' : '') + '>Next</button>';
        html += '</div>';
        el.innerHTML = html;
        el.querySelectorAll('button[data-p]').forEach(function (b) {
            b.addEventListener('click', function () {
                if (b.disabled) return;
                onPage(parseInt(b.getAttribute('data-p'), 10));
            });
        });
    };

    G.openModal = function (el) {
        if (!el) return;
        el.hidden = false;
        el.classList.add('is-open');
    };

    G.closeModal = function (el) {
        if (!el) return;
        el.classList.remove('is-open');
        el.hidden = true;
    };

    G.ready(function () {
        var btn = document.getElementById('menu-btn');
        var side = document.getElementById('sidebar');
        var back = document.getElementById('backdrop');
        if (!btn || !side) return;
        function close() {
            side.classList.remove('open');
            if (back) back.classList.remove('show');
        }
        btn.addEventListener('click', function () {
            side.classList.toggle('open');
            if (back) back.classList.toggle('show');
        });
        if (back) back.addEventListener('click', close);
    });

    w.GymLead = G;
})(window);
