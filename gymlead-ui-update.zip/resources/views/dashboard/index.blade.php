@extends('layouts.app')
@section('title', 'Dashboard')
@section('heading', 'Dashboard')
@section('subhead', 'Live snapshot of pipeline health and ownership.')
@section('actions')
    <a class="btn btn-ghost" href="{{ route('leads.index') }}">Open leads</a>
    @if(auth()->user()->isAdmin())
        <a class="btn btn-primary" href="{{ route('scraper.index') }}">Source from Maps</a>
    @else
        <a class="btn btn-primary" href="{{ route('leads.create') }}">Add lead</a>
    @endif
@endsection
@section('content')
<div class="stat-grid" id="stat-grid">
    <article class="stat">
        <div class="stat-ico"><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M8 6h13M8 12h13M8 18h13"/></svg></div>
        <div><span>Total leads</span><strong id="st-leads">—</strong></div>
    </article>
    <article class="stat">
        <div class="stat-ico"><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/></svg></div>
        <div><span>New</span><strong id="st-new">—</strong></div>
    </article>
    <article class="stat">
        <div class="stat-ico ok"><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m5 13 4 4L19 7"/></svg></div>
        <div><span>Converted</span><strong id="st-converted">—</strong></div>
    </article>
    <article class="stat">
        <div class="stat-ico slate"><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="4" y="5" width="16" height="15" rx="2"/><path d="M8 3v4M16 3v4M4 10h16"/></svg></div>
        <div><span>Added today</span><strong id="st-today">—</strong></div>
    </article>
    @if(auth()->user()->isAdmin())
        <article class="stat">
            <div class="stat-ico warn"><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16h.01"/></svg></div>
            <div><span>Unassigned</span><strong id="st-unassigned">—</strong></div>
        </article>
        <article class="stat">
            <div class="stat-ico"><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="9" cy="8" r="3"/><path d="M3.5 19a5.5 5.5 0 0 1 11 0"/></svg></div>
            <div><span>Active staff</span><strong id="st-staff">—</strong></div>
        </article>
    @endif
</div>
<div class="grid-2">
    <section class="panel">
        <header class="panel-h"><h2>Pipeline</h2></header>
        <div id="pipeline" class="pipeline"></div>
    </section>
    <section class="panel">
        <header class="panel-h"><h2>Due follow-ups</h2></header>
        <div id="followups" class="list"></div>
    </section>
</div>
<section class="panel">
    <header class="panel-h">
        <h2>Latest leads</h2>
        <a href="{{ route('leads.index') }}">View all</a>
    </header>
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr><th>Lead</th><th>Status</th><th>Owner</th><th>Added</th></tr>
            </thead>
            <tbody id="recent"></tbody>
        </table>
    </div>
</section>
@endsection
@push('scripts')
<script>
GymLead.ready(function () {
    GymLead.get('{{ route('dashboard.stats') }}').then(function (res) {
        if (!res.ok) return;
        document.getElementById('st-leads').textContent = res.totals.leads;
        document.getElementById('st-new').textContent = res.totals.new;
        document.getElementById('st-converted').textContent = res.totals.converted;
        document.getElementById('st-today').textContent = res.totals.today;
        var u = document.getElementById('st-unassigned');
        var s = document.getElementById('st-staff');
        if (u) u.textContent = res.totals.unassigned;
        if (s) s.textContent = res.totals.staff;
        var max = 1;
        res.pipeline.forEach(function (p) { if (p.count > max) max = p.count; });
        document.getElementById('pipeline').innerHTML = res.pipeline.map(function (p) {
            var w = Math.round((p.count / max) * 100);
            return '<div class="pipe"><div class="pipe-meta"><span>' + GymLead.esc(p.label) + '</span><b>' + p.count + '</b></div><div class="bar"><i style="width:' + w + '%"></i></div></div>';
        }).join('');
        document.getElementById('followups').innerHTML = res.follow_ups.length
            ? res.follow_ups.map(function (l) {
                return '<a class="rowlink" href="/leads/' + l.id + '"><span class="entity"><span class="avatar sm">' + GymLead.esc((l.name || '?').charAt(0).toUpperCase()) + '</span><strong>' + GymLead.esc(l.name) + '</strong></span><small>' + GymLead.esc(l.follow_up_at || '') + '</small></a>';
            }).join('')
            : '<div class="empty">No follow-ups due.</div>';
        document.getElementById('recent').innerHTML = res.recent.length
            ? res.recent.map(function (l) {
                return '<tr><td><div class="entity"><span class="avatar sm">' + GymLead.esc((l.name || '?').charAt(0).toUpperCase()) + '</span><div><strong>' + GymLead.esc(l.name) + '</strong><div class="sub">' + GymLead.esc(l.city || '') + '</div></div></div></td><td><span class="badge">' + GymLead.esc(l.status) + '</span></td><td>' + GymLead.esc(l.assigned || 'Unassigned') + '</td><td class="muted">' + GymLead.esc(l.created_at) + '</td></tr>';
            }).join('')
            : '<tr><td colspan="4" class="empty">No leads yet.</td></tr>';
    });
});
</script>
@endpush
