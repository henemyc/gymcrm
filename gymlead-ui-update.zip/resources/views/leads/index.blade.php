@extends('layouts.app')
@section('title', 'Leads')
@section('heading', auth()->user()->isAdmin() ? 'Leads' : 'My leads')
@section('subhead', 'Search, filter, assign ownership, and move status.')
@section('actions')
    <a class="btn btn-ghost" href="{{ route('leads.export') }}">Export CSV</a>
    <a class="btn btn-primary" href="{{ route('leads.create') }}">New lead</a>
@endsection
@section('content')
<section class="panel">
    <form class="filters" id="lead-filters">
        <input type="search" name="q" placeholder="Search name, phone, city…" autocomplete="off">
        <select name="status">
            <option value="">All statuses</option>
            @foreach($statuses as $st)
                <option value="{{ $st->value }}">{{ $st->label() }}</option>
            @endforeach
        </select>
        <select name="source">
            <option value="">All sources</option>
            @foreach($sources as $src)
                <option value="{{ $src->value }}">{{ $src->label() }}</option>
            @endforeach
        </select>
        @if(auth()->user()->isAdmin())
            <select name="assigned_to">
                <option value="">All owners</option>
                <option value="unassigned">Unassigned</option>
                @foreach($staff as $s)
                    <option value="{{ $s->id }}">{{ $s->name }}</option>
                @endforeach
            </select>
        @endif
        <label class="check"><input type="checkbox" name="follow_up" value="1"> Due follow-up</label>
        <label class="pager-size">Per page
            <select name="per_page">
                <option value="10">10</option>
                <option value="15" selected>15</option>
                <option value="25">25</option>
                <option value="50">50</option>
            </select>
        </label>
        <button class="btn btn-ghost" type="submit">Apply</button>
    </form>

    @if(auth()->user()->isAdmin())
    <div class="bulkbar" id="bulkbar" hidden>
        <span id="bulk-count">0 selected</span>
        <select id="bulk-staff">
            <option value="">Assign to…</option>
            @foreach($staff as $s)
                <option value="{{ $s->id }}">{{ $s->name }}</option>
            @endforeach
        </select>
        <button class="btn btn-primary" type="button" id="bulk-assign">Assign</button>
        <select id="bulk-status">
            <option value="">Set status…</option>
            @foreach($statuses as $st)
                <option value="{{ $st->value }}">{{ $st->label() }}</option>
            @endforeach
        </select>
        <button class="btn btn-ghost" type="button" id="bulk-status-go">Update</button>
        <button class="btn btn-danger" type="button" id="bulk-delete">Delete</button>
        <button class="btn btn-ghost" type="button" id="bulk-export">Export selected</button>
    </div>
    @else
    <div class="bulkbar" id="bulkbar" hidden>
        <span id="bulk-count">0 selected</span>
        <select id="bulk-status">
            <option value="">Set status…</option>
            @foreach($statuses as $st)
                <option value="{{ $st->value }}">{{ $st->label() }}</option>
            @endforeach
        </select>
        <button class="btn btn-ghost" type="button" id="bulk-status-go">Update</button>
    </div>
    @endif

    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th class="col-check"><input type="checkbox" id="check-all"></th>
                    <th>Lead</th>
                    <th>Contact</th>
                    <th>Status</th>
                    <th>Owner</th>
                    <th>Source</th>
                    <th>Added</th>
                </tr>
            </thead>
            <tbody id="lead-rows">
                <tr><td colspan="7" class="muted">Loading…</td></tr>
            </tbody>
        </table>
    </div>
    <div class="pager" id="pager"></div>
</section>
@endsection
@push('scripts')
<script>
GymLead.ready(function () {
    var page = 1;
    var selected = {};

    function params() {
        var fd = new FormData(document.getElementById('lead-filters'));
        var q = new URLSearchParams();
        fd.forEach(function (v, k) { if (v) q.set(k, v); });
        q.set('page', page);
        return q.toString();
    }

    function load() {
        GymLead.get('{{ route('leads.datatable') }}?' + params()).then(function (res) {
            if (!res.ok) return;
            var tb = document.getElementById('lead-rows');
            if (!res.data.length) {
                tb.innerHTML = '<tr><td colspan="7"><div class="empty">No leads match these filters.</div></td></tr>';
            } else {
                tb.innerHTML = res.data.map(function (l) {
                    var checked = selected[l.id] ? 'checked' : '';
                    var initial = GymLead.esc((l.name || '?').charAt(0).toUpperCase());
                    return '<tr>' +
                        '<td class="col-check"><input type="checkbox" class="row-check" value="' + l.id + '" ' + checked + '></td>' +
                        '<td><a class="entity" href="' + l.url + '"><span class="avatar sm">' + initial + '</span><span><strong>' + GymLead.esc(l.name) + '</strong><div class="sub">' + GymLead.esc(l.city || l.address || '') + '</div></span></a></td>' +
                        '<td>' + GymLead.esc(l.phone || '—') + '</td>' +
                        '<td><span class="badge ' + l.badge + '">' + GymLead.esc(l.status_label) + '</span></td>' +
                        '<td>' + GymLead.esc(l.assignee || 'Unassigned') + '</td>' +
                        '<td><span class="badge">' + GymLead.esc(l.source_label) + '</span></td>' +
                        '<td class="muted">' + GymLead.esc(l.created_at) + '</td></tr>';
                }).join('');
            }
            GymLead.pager('pager', res.meta, function (p) { page = p; load(); });
            bindChecks();
        });
    }

    function ids() { return Object.keys(selected).filter(function (k) { return selected[k]; }); }
    function refreshBulk() {
        var n = ids().length;
        document.getElementById('bulkbar').hidden = n === 0;
        document.getElementById('bulk-count').textContent = n + ' selected';
    }
    function bindChecks() {
        document.querySelectorAll('.row-check').forEach(function (c) {
            c.addEventListener('change', function () {
                selected[c.value] = c.checked;
                if (!c.checked) delete selected[c.value];
                refreshBulk();
            });
        });
    }

    document.getElementById('lead-filters').addEventListener('submit', function (e) {
        e.preventDefault(); page = 1; load();
    });
    document.getElementById('check-all').addEventListener('change', function () {
        document.querySelectorAll('.row-check').forEach(function (c) {
            c.checked = document.getElementById('check-all').checked;
            if (c.checked) selected[c.value] = true; else delete selected[c.value];
        });
        refreshBulk();
    });

    var assignBtn = document.getElementById('bulk-assign');
    if (assignBtn) {
        assignBtn.addEventListener('click', function () {
            var staff = document.getElementById('bulk-staff').value;
            if (!staff) return GymLead.toast('Pick a staff member.', 'err');
            GymLead.post('{{ route('leads.bulk.assign') }}', { ids: ids(), assigned_to: staff }).then(function (res) {
                GymLead.toast(res.message); selected = {}; load(); refreshBulk();
            });
        });
    }
    document.getElementById('bulk-status-go').addEventListener('click', function () {
        var st = document.getElementById('bulk-status').value;
        if (!st) return GymLead.toast('Pick a status.', 'err');
        GymLead.post('{{ route('leads.bulk.status') }}', { ids: ids(), status: st }).then(function (res) {
            GymLead.toast(res.message); selected = {}; load(); refreshBulk();
        });
    });
    var del = document.getElementById('bulk-delete');
    if (del) {
        del.addEventListener('click', function () {
            if (!confirm('Delete selected leads?')) return;
            GymLead.post('{{ route('leads.bulk.delete') }}', { ids: ids() }).then(function (res) {
                GymLead.toast(res.message); selected = {}; load(); refreshBulk();
            });
        });
    }
    var exp = document.getElementById('bulk-export');
    if (exp) {
        exp.addEventListener('click', function () {
            GymLead.downloadPost('{{ route('leads.bulk.export') }}', { ids: ids() }, 'leads-selected.csv');
        });
    }
    load();
});
</script>
@endpush
