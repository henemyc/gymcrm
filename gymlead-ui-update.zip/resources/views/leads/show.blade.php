@extends('layouts.app')
@section('title', $lead->name)
@section('heading', $lead->name)
@section('subhead', $lead->sourceEnum()->label() . ' · Lead #' . $lead->id)
@section('actions')
    <a class="btn btn-ghost" href="{{ route('leads.index') }}">Back to leads</a>
    <a class="btn btn-primary" href="{{ route('leads.edit', $lead) }}">Edit record</a>
@endsection
@section('content')
<div class="grid-2">
    <section class="panel">
        <header class="panel-h">
            <h2>Contact record</h2>
            <span class="badge {{ $lead->statusEnum()->badgeClass() }}">{{ $lead->statusEnum()->label() }}</span>
        </header>
        <div class="entity" style="margin-bottom:18px">
            <span class="avatar">{{ strtoupper(substr($lead->name, 0, 1)) }}</span>
            <div>
                <strong>{{ $lead->name }}</strong>
                <div class="sub">{{ $lead->category ?: 'Business' }} @if($lead->rating) · {{ $lead->rating }} ({{ $lead->reviews_count }} reviews) @endif</div>
            </div>
        </div>
        <dl class="facts">
            <div><dt>Phone</dt><dd>{{ $lead->phone ?: '—' }}</dd></div>
            <div><dt>Email</dt><dd>{{ $lead->email ?: '—' }}</dd></div>
            <div><dt>Website</dt><dd>@if($lead->website)<a href="{{ $lead->website }}" target="_blank" rel="noopener">{{ $lead->website }}</a>@else — @endif</dd></div>
            <div><dt>Address</dt><dd>{{ $lead->address ?: '—' }}</dd></div>
            <div><dt>City / state</dt><dd>{{ trim(($lead->city ?: '—').' '.$lead->state) }}</dd></div>
            <div><dt>Owner</dt><dd>{{ $lead->assignee->name ?? 'Unassigned' }}</dd></div>
            <div><dt>Follow up</dt><dd>{{ optional($lead->follow_up_at)->format('d M Y') ?: '—' }}</dd></div>
            <div><dt>Last contact</dt><dd>{{ optional($lead->last_contacted_at)->format('d M Y H:i') ?: '—' }}</dd></div>
        </dl>
        @if($lead->google_maps_url)
            <p style="margin-top:16px"><a class="btn btn-ghost" href="{{ $lead->google_maps_url }}" target="_blank" rel="noopener">Open in Google Maps</a></p>
        @endif
    </section>
    <section class="panel">
        <header class="panel-h"><h2>Pipeline actions</h2></header>
        <form id="status-form" class="stack">
            <label>Status
                <select name="status">
                    @foreach($statuses as $st)
                        <option value="{{ $st->value }}" @selected($lead->status === $st->value)>{{ $st->label() }}</option>
                    @endforeach
                </select>
            </label>
            <label>Follow-up date
                <input type="date" name="follow_up_at" value="{{ optional($lead->follow_up_at)->format('Y-m-d') }}">
            </label>
            <button class="btn btn-primary" type="submit">Update status</button>
        </form>
        @if(auth()->user()->isAdmin())
            <hr>
            <form id="assign-form" class="stack">
                <label>Owner
                    <select name="assigned_to" required>
                        <option value="">Select staff</option>
                        @foreach($staff as $s)
                            <option value="{{ $s->id }}" @selected((int)$lead->assigned_to === (int)$s->id)>{{ $s->name }}</option>
                        @endforeach
                    </select>
                </label>
                <button class="btn btn-ghost" type="submit">Assign owner</button>
            </form>
        @endif
    </section>
</div>
<section class="panel">
    <header class="panel-h"><h2>Activity notes</h2></header>
    <form id="note-form" class="stack">
        <textarea name="body" rows="3" required placeholder="Call outcome, objections, next step…"></textarea>
        <div><button class="btn btn-primary" type="submit">Add note</button></div>
    </form>
    <div id="notes" class="notes">
        @forelse($lead->leadNotes as $note)
            <article>
                <strong>{{ $note->user->name ?? 'User' }}</strong>
                <small>{{ $note->created_at->diffForHumans() }}</small>
                <p>{{ $note->body }}</p>
            </article>
        @empty
            <p class="muted" id="no-notes">No notes yet. Log the first conversation.</p>
        @endforelse
    </div>
</section>
@endsection
@push('scripts')
<script>
GymLead.ready(function () {
    document.getElementById('status-form').addEventListener('submit', function (e) {
        e.preventDefault();
        GymLead.post('{{ route('leads.status', $lead) }}', GymLead.formData(this)).then(function (res) {
            GymLead.toast(res.message);
        });
    });
    var af = document.getElementById('assign-form');
    if (af) {
        af.addEventListener('submit', function (e) {
            e.preventDefault();
            GymLead.post('{{ route('leads.bulk.assign') }}', {
                ids: [{{ $lead->id }}],
                assigned_to: this.assigned_to.value
            }).then(function (res) { GymLead.toast(res.message); });
        });
    }
    document.getElementById('note-form').addEventListener('submit', function (e) {
        e.preventDefault();
        var form = this;
        GymLead.post('{{ route('leads.notes.store', $lead) }}', GymLead.formData(form)).then(function (res) {
            GymLead.toast(res.message);
            var empty = document.getElementById('no-notes');
            if (empty) empty.remove();
            var art = document.createElement('article');
            art.innerHTML = '<strong>' + GymLead.esc(res.note.user) + '</strong><small> ' + GymLead.esc(res.note.created_at) + '</small><p>' + GymLead.esc(res.note.body) + '</p>';
            document.getElementById('notes').prepend(art);
            form.reset();
        });
    });
});
</script>
@endpush
