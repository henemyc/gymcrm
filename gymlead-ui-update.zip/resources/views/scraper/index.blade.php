@extends('layouts.app')
@section('title', 'Maps scraper')
@section('heading', 'Maps scraper')
@section('subhead', 'Search a location, preview businesses, then assign selected leads to staff.')
@section('actions')
    <a class="btn btn-ghost" href="{{ route('settings.index') }}">API settings</a>
@endsection
@section('content')
@if(!$hasKey)
    <div class="alert err">No Google Maps API key yet. Add it in <a href="{{ route('settings.index') }}">Settings</a> before searching.</div>
@endif
<section class="panel">
    <form id="scrape-form" class="form-grid">
        <label class="span-2">Location
            <input type="text" name="location" id="location" placeholder="Start typing a city, area, or landmark…" autocomplete="off" required>
            <input type="hidden" name="place_id" id="place_id">
            <div id="suggest" class="suggest" hidden></div>
        </label>
        <label>Keyword
            <input name="keyword" value="{{ $defaults['keyword'] }}" required>
        </label>
        <label>Place type
            <select name="type">
                @foreach($types as $k => $label)
                    <option value="{{ $k }}" @selected($k === 'gym')>{{ $label }}</option>
                @endforeach
            </select>
        </label>
        <label>Radius (metres)
            <input type="number" name="radius" min="50" max="{{ $defaults['max_radius'] }}" value="{{ $defaults['radius'] }}">
        </label>
        <label>Mode
            <select name="mode">
                <option value="nearby">Nearby search</option>
                <option value="text">Text search</option>
            </select>
        </label>
        <div class="span-2">
            <button class="btn btn-primary" type="submit" {{ $hasKey ? '' : 'disabled' }}>Search Maps</button>
            <span class="hint">Up to {{ $defaults['max_pages'] }} pages (max 60 places). Duplicates are flagged, not saved twice.</span>
        </div>
    </form>
</section>
<section class="panel" id="results-panel" hidden>
    <header class="panel-h">
        <h2>Preview <small id="result-meta"></small></h2>
        <div class="topbar-actions">
            <label class="check"><input type="checkbox" id="pick-all"> Select all new</label>
        </div>
    </header>
    <div class="bulkbar">
        <span id="pick-count">0 selected</span>
        <select id="assign-staff" required>
            <option value="">Assign selected to…</option>
            @foreach($staff as $s)
                <option value="{{ $s->id }}">{{ $s->name }}</option>
            @endforeach
        </select>
        <button class="btn btn-ghost" type="button" id="enrich-btn">Load phones / websites</button>
        <button class="btn btn-primary" type="button" id="assign-btn">Save & assign</button>
    </div>
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th></th>
                    <th>Business</th>
                    <th>Address</th>
                    <th>Rating</th>
                    <th>Phone</th>
                    <th>Flag</th>
                </tr>
            </thead>
            <tbody id="scrape-rows"></tbody>
        </table>
    </div>
    <div class="pager" id="scrape-pager"></div>
</section>
<section class="panel">
    <header class="panel-h"><h2>Recent scrape jobs</h2></header>
    <div id="jobs" class="list"></div>
    <div class="pager" id="jobs-pager"></div>
</section>
@endsection
@push('scripts')
<script>
GymLead.ready(function () {
    var jobId = null;
    var items = [];
    var timer = null;
    var previewPage = 1;
    var previewPer = 15;
    var jobsPage = 1;
    var picked = {};
    var loc = document.getElementById('location');
    var box = document.getElementById('suggest');

    loc.addEventListener('input', function () {
        document.getElementById('place_id').value = '';
        clearTimeout(timer);
        var q = loc.value.trim();
        if (q.length < 2) { box.hidden = true; return; }
        timer = setTimeout(function () {
            GymLead.get('{{ route('scraper.autocomplete') }}?q=' + encodeURIComponent(q)).then(function (res) {
                if (!res.ok) { GymLead.toast(res.message || 'Autocomplete failed', 'err'); return; }
                box.hidden = false;
                box.innerHTML = (res.predictions || []).map(function (p) {
                    return '<button type="button" data-id="' + GymLead.esc(p.place_id) + '">' + GymLead.esc(p.description) + '</button>';
                }).join('') || '<p class="muted">No matches</p>';
            });
        }, 280);
    });
    box.addEventListener('click', function (e) {
        var b = e.target.closest('button');
        if (!b) return;
        loc.value = b.textContent;
        document.getElementById('place_id').value = b.getAttribute('data-id');
        box.hidden = true;
    });
    document.addEventListener('click', function (e) {
        if (!box.contains(e.target) && e.target !== loc) box.hidden = true;
    });

    document.getElementById('scrape-form').addEventListener('submit', function (e) {
        e.preventDefault();
        GymLead.toast('Searching Google Places…');
        GymLead.post('{{ route('scraper.search') }}', GymLead.formData(this)).then(function (res) {
            if (!res.ok) return;
            jobId = res.job_id;
            items = res.items || [];
            picked = {};
            previewPage = 1;
            render();
            document.getElementById('results-panel').hidden = false;
            document.getElementById('result-meta').textContent = res.found + ' found · ' + res.duplicates + ' already in CRM';
            GymLead.toast('Preview ready.');
        });
    });

    function selectedPlaces() {
        return items.filter(function (it, i) {
            return picked[i] && !it.is_duplicate;
        });
    }

    function render() {
        var last = Math.max(1, Math.ceil(items.length / previewPer));
        if (previewPage > last) previewPage = last;
        var start = (previewPage - 1) * previewPer;
        var slice = items.slice(start, start + previewPer);
        document.getElementById('scrape-rows').innerHTML = slice.map(function (it) {
            var i = items.indexOf(it);
            var disabled = it.is_duplicate ? 'disabled' : '';
            var checked = picked[i] ? 'checked' : '';
            var flag = it.is_duplicate ? '<span class="badge badge-duplicate">Duplicate</span>' : '<span class="badge badge-new">New</span>';
            return '<tr class="' + (it.is_duplicate ? 'dim' : '') + '">' +
                '<td class="col-check"><input type="checkbox" class="pick" data-i="' + i + '" ' + disabled + ' ' + checked + '></td>' +
                '<td><strong>' + GymLead.esc(it.name) + '</strong><div class="muted">' + GymLead.esc(it.category || '') + '</div></td>' +
                '<td>' + GymLead.esc(it.address || '') + '</td>' +
                '<td>' + GymLead.esc(String(it.rating || '—')) + '</td>' +
                '<td>' + GymLead.esc(it.phone || '—') + '</td>' +
                '<td>' + flag + '</td></tr>';
        }).join('');
        document.querySelectorAll('.pick').forEach(function (c) {
            c.addEventListener('change', function () {
                if (c.checked) picked[c.getAttribute('data-i')] = true;
                else delete picked[c.getAttribute('data-i')];
                updateCount();
            });
        });
        GymLead.pager('scrape-pager', {
            current_page: previewPage,
            last_page: last,
            total: items.length,
            per_page: previewPer
        }, function (p) { previewPage = p; render(); });
        updateCount();
    }

    function updateCount() {
        document.getElementById('pick-count').textContent = selectedPlaces().length + ' selected';
    }

    document.getElementById('pick-all').addEventListener('change', function () {
        var on = this.checked;
        items.forEach(function (it, i) {
            if (it.is_duplicate) return;
            if (on) picked[i] = true;
            else delete picked[i];
        });
        render();
    });

    document.getElementById('enrich-btn').addEventListener('click', function () {
        var sel = selectedPlaces();
        if (!sel.length) return GymLead.toast('Select places first.', 'err');
        GymLead.post('{{ route('scraper.enrich') }}', {
            place_ids: sel.map(function (p) { return p.google_place_id; })
        }).then(function (res) {
            (res.items || []).forEach(function (d) {
                items = items.map(function (it) {
                    if (it.google_place_id === d.google_place_id) return Object.assign({}, it, d);
                    return it;
                });
            });
            render();
            GymLead.toast('Contact details loaded.');
        });
    });

    document.getElementById('assign-btn').addEventListener('click', function () {
        var sel = selectedPlaces();
        var staff = document.getElementById('assign-staff').value;
        if (!sel.length) return GymLead.toast('Select at least one new place.', 'err');
        if (!staff) return GymLead.toast('Pick a staff member.', 'err');
        if (!jobId) return GymLead.toast('Run a search first.', 'err');
        GymLead.post('{{ route('scraper.assign') }}', {
            job_id: jobId,
            assigned_to: staff,
            places: sel
        }).then(function (res) {
            GymLead.toast(res.message);
            loadJobs();
        });
    });

    function loadJobs() {
        GymLead.get('{{ route('scraper.jobs') }}?page=' + jobsPage + '&per_page=10').then(function (res) {
            document.getElementById('jobs').innerHTML = (res.jobs || []).map(function (j) {
                return '<div class="rowlink"><strong>' + GymLead.esc(j.location_label || j.keyword || 'Job') + '</strong><small>' +
                    GymLead.esc(j.status) + ' · found ' + j.results_found + ' · saved ' + j.saved_count + '</small></div>';
            }).join('') || '<p class="muted">No jobs yet.</p>';
            if (res.meta) GymLead.pager('jobs-pager', res.meta, function (p) { jobsPage = p; loadJobs(); });
        });
    }
    loadJobs();
});
</script>
@endpush
