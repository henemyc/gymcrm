@extends('layouts.app')
@section('title', 'Team')
@section('heading', 'Team')
@section('subhead', 'Admins manage the workspace. Staff only see assigned leads.')
@section('actions')
    <button class="btn btn-primary" type="button" id="open-create">Invite user</button>
@endsection
@section('content')
<section class="panel">
    <form class="filters" id="user-filters">
        <input type="search" name="q" placeholder="Search name or email">
        <select name="role">
            <option value="">All roles</option>
            @foreach($roles as $r)
                <option value="{{ $r->value }}">{{ $r->label() }}</option>
            @endforeach
        </select>
        <label class="pager-size">Per page
            <select name="per_page" id="user-per-page">
                <option value="10">10</option>
                <option value="15" selected>15</option>
                <option value="25">25</option>
                <option value="50">50</option>
            </select>
        </label>
        <button class="btn btn-ghost" type="submit">Apply</button>
    </form>
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr><th>Name</th><th>Email</th><th>Role</th><th>Leads</th><th>Status</th><th></th></tr>
            </thead>
            <tbody id="user-rows"></tbody>
        </table>
    </div>
    <div class="pager" id="pager"></div>
</section>

<div class="modal" id="user-modal" style="display:none" onclick="if (event.target === this) closeUserModal();">
    <div class="modal-card" onclick="event.stopPropagation();">
        <header class="panel-h">
            <h2 id="modal-title">Add user</h2>
            <button type="button" class="btn btn-ghost" id="close-modal" onclick="closeUserModal(); return false;">Close</button>
        </header>
        <form id="user-form" class="form-grid">
            <input type="hidden" name="id">
            <label class="span-2">Name <input name="name" required></label>
            <label>Email <input type="email" name="email" required></label>
            <label>Phone <input name="phone"></label>
            <label>Role
                <select name="role" required>
                    <option value="staff">Staff</option>
                    <option value="admin">Admin</option>
                </select>
            </label>
            <label>Daily lead cap <input type="number" name="daily_lead_limit" min="0" value="0"></label>
            <label>Password <input type="password" name="password" minlength="8"></label>
            <label class="check span-2"><input type="checkbox" name="is_active" value="1" checked> Active</label>
            <div class="span-2" style="display:flex;gap:8px">
                <button class="btn btn-primary" type="submit">Save</button>
                <button class="btn btn-ghost" type="button" onclick="closeUserModal(); return false;">Cancel</button>
            </div>
        </form>
    </div>
</div>
@endsection
@push('scripts')
<script>
GymLead.ready(function () {
    var page = 1;
    function load() {
        var q = new URLSearchParams(new FormData(document.getElementById('user-filters')));
        q.set('page', page);
        GymLead.get('{{ route('users.datatable') }}?' + q.toString()).then(function (res) {
            document.getElementById('user-rows').innerHTML = res.data.map(function (u) {
                return '<tr><td><strong>' + GymLead.esc(u.name) + '</strong></td><td>' + GymLead.esc(u.email) + '</td><td>' +
                    GymLead.esc(u.role) + '</td><td>' + u.assigned_leads_count + '</td><td>' +
                    (u.is_active ? '<span class="badge badge-converted">Active</span>' : '<span class="badge badge-not">Disabled</span>') +
                    '</td><td><button class="linkish edit" data-id="' + u.id + '">Edit</button> · ' +
                    '<button class="linkish toggle" data-id="' + u.id + '">Toggle</button></td></tr>';
            }).join('') || '<tr><td colspan="6" class="muted">No users</td></tr>';
            GymLead.pager('pager', res.meta, function (p) { page = p; load(); });
        });
    }
    document.getElementById('user-filters').addEventListener('submit', function (e) { e.preventDefault(); page = 1; load(); });
    document.getElementById('open-create').addEventListener('click', function () {
        document.getElementById('user-form').reset();
        document.querySelector('[name=id]').value = '';
        document.getElementById('modal-title').textContent = 'Add user';
        openUserModal();
    });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') closeUserModal();
    });
    document.getElementById('user-rows').addEventListener('click', function (e) {
        var ed = e.target.closest('.edit');
        var tg = e.target.closest('.toggle');
        if (ed) {
            GymLead.get('{{ url('/users') }}/' + ed.dataset.id).then(function (res) {
                var u = res.user;
                var f = document.getElementById('user-form');
                f.id.value = u.id;
                f.name.value = u.name;
                f.email.value = u.email;
                f.phone.value = u.phone || '';
                f.role.value = u.role;
                f.daily_lead_limit.value = u.daily_lead_limit;
                f.is_active.checked = !!u.is_active;
                document.getElementById('modal-title').textContent = 'Edit user';
                openUserModal();
            });
        }
        if (tg) {
            GymLead.post('{{ url('/users') }}/' + tg.dataset.id + '/toggle', {}).then(function (res) {
                GymLead.toast(res.message); load();
            });
        }
    });
    document.getElementById('user-form').addEventListener('submit', function (e) {
        e.preventDefault();
        var data = GymLead.formData(this);
        data.is_active = this.is_active.checked ? 1 : 0;
        var id = data.id;
        delete data.id;
        var url = id ? '{{ url('/users') }}/' + id : '{{ route('users.store') }}';
        var method = id ? 'PUT' : 'POST';
        GymLead.send(method, url, data).then(function (res) {
            GymLead.toast(res.message); closeUserModal(); load();
        });
    });
    load();
});
</script>
@endpush
